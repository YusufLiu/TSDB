from __future__ import print_function
import boto3
import json
import uuid
import requests
from decimal import *

def lambda_handler(event, context):
    #check if the event has content
    try:
        packet = json.loads(event['body'])
    except KeyError:
        packet = event

    site = packet['site'].replace(' ','_')
    location = packet['location']
    unit = packet['unit']
    measurement = packet['name']
    #for each measurements in the event
    for record in packet['data']:
        time = record['ts']*1000000000
        value = record['value']
        data = measurements + ',site='+site+',location='+location+',unit='+unit+' value='+value+' '+time
        # insert into the database
        r = requests.post(url='http://52.206.6.10:8086/write?db=Senseware', data=data, headers={'Content-Type': 'application/octet-stream'})
